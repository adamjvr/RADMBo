$Id:: readme.txt 6 2007-08-27 20:47:57Z kevinw                       $

These tools are required by the LPC Software package build system to
run Makefiles.

************************************************************************
The following tools are available from http://unxutils.sourceforge.net/

cp.exe, ls.exe, make.exe, makedepend.exe, mkdir.exe, mv.exe, rm.exe,
sh.exe, rmdir.exe

************************************************************************
The following tools are available from http://www.cygwin.com/

cygwin1.dll, arm-elf-objcopy.exe
